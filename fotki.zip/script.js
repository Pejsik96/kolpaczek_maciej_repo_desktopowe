$(function ()
{
    $('#my-image').on('click', function ()
    {
        $(this).width(1000);
    });
});