var oceny;
(function (oceny) {
    oceny[oceny["Ndst"] = 1] = "Ndst";
    oceny[oceny["Dop"] = 2] = "Dop";
    oceny[oceny["Dst"] = 3] = "Dst";
    oceny[oceny["Db"] = 4] = "Db";
    oceny[oceny["Bdb"] = 5] = "Bdb";
    oceny[oceny["Cel"] = 6] = "Cel";
})(oceny || (oceny = {}));
var przedmioty = ["Matematyka", "Polski", "Geografia", "WF", "Chemia", "Biologia", "Muzyka", "Plastyka", "Angielski", "Niemiecki"];
function LosowaOcena(ilosc) {
    var oceny = [];
    for (var i = 0; i < ilosc; i++) {
        oceny.push(Math.floor(Math.random() * (6) + 1));
    }
    console.log("" + oceny);
}
function OcenyWaga() {
    var Truple = [];
    for (var i = 0; i < 4; i++) {
        var stopien = Math.floor(Math.random() * (6) + 1);
        var waga_1 = Math.floor(Math.random() * (5) + 1);
        Truple[i] = [oceny[stopien], przedmioty[1], waga_1, stopien];
    }
    var sredniaOcen = 0;
    var waga = 0;
    var sredniaWazona = 0;
    for (var i = 0; i < 4; i++) {
        waga = Truple[i][2] * Truple[i][3];
        sredniaWazona += Truple[i][2];
        sredniaOcen += waga;
    }
    console.log("Średnia losowa:" + (sredniaOcen / sredniaWazona).toFixed(2));
}
function OcenyPrzedmiot() {
    var Truple = [];
    var x = 0;
    for (var j = 0; j < 10; j++) {
        var subject = przedmioty[j];
        for (var i = 0; i < Math.random() * 10 + 1; i++) {
            var stopien = Math.floor(Math.random() * 6 + 1);
            var waga = Math.floor(Math.random() * 5 + 1);
            Truple[x] = [oceny[stopien], subject, waga, stopien];
            console.log(subject + " Ocena:" + stopien + " Waga:" + waga);
            x++;
        }
    }
    console.log(Truple);
}
