enum oceny{
    Ndst = 1,
    Dop = 2,
    Dst = 3,
    Db = 4,
    Bdb = 5,
    Cel = 6
}
let przedmioty = ["Matematyka", "Polski", "Geografia", "WF", "Chemia", "Biologia", "Muzyka", "Plastyka", "Angielski", "Niemiecki"];
type stopnie = [string, string, number, number]; 
function LosowaOcena(ilosc:number){
    let oceny:number[] = [];
    for(var i:number=0;i<ilosc;i++){
        oceny.push(Math.floor(Math.random() * (6) + 1));
    }
    console.log(""+oceny);
}
function OcenyWaga(){
    let Truple:stopnie[] = [];
    for(var i:number=0;i<4;i++){
        let stopien = Math.floor(Math.random() * (6) + 1);
        let waga = Math.floor(Math.random() * (5) + 1);
        Truple[i] = [oceny[stopien], przedmioty[1], waga, stopien];
    }
    let sredniaOcen:number = 0;
    let waga:number = 0;
    let sredniaWazona:number = 0;
    for(var i:number=0;i<4;i++){
        waga = Truple[i][2]*Truple[i][3];
        sredniaWazona+=Truple[i][2];
        sredniaOcen+=waga;
    }
    console.log("Średnia losowa:"+(sredniaOcen/sredniaWazona).toFixed(2));
}

function OcenyPrzedmiot(){
    let Truple:stopnie[] = [];
    let x:number = 0;
    for(var j:number=0;j<10;j++){
        let subject = przedmioty[j];
        for(var i:number=0;i<Math.random() * 10 + 1;i++){   
            let stopien = Math.floor(Math.random() * 6 + 1);
            let waga = Math.floor(Math.random() * 5 + 1);
            Truple[x] = [oceny[stopien], subject, waga, stopien];
            console.log(subject+" Ocena:"+stopien+" Waga:"+waga);
            x++;
        }
    }
    console.log(Truple);
    
}
