var table = [
    new Cinema("1", 10, 15, "Test1"),
    new Cinema("2", 50, 18, "Test2"),
    new Cinema("3", 34, 20, "Test3"),
    new Cinema("1", 2, 15, "Test4"),
    new Cinema("2", 43, 18, "Test5"),
    new Cinema("3", 5, 20, "Test6"),
    new Cinema("1", 2, 15, "Test7"),
    new Cinema("2", 3, 18, "Test8"),
    new Cinema("3", 10, 20, "Test9"),
    new Cinema("1", 1, 15, "Test10")


]

console.log("Przed sortowaniem");
for(var i:number=0;i<10;i++){
    console.log(table[i].emptySpaces);
}


/*
 **************************************
 nazwa funkcji: sortArray
 argumenty: obiekt Cinema oraz obiekt Cinema
 typ zwracany: -1, 1, 0
 informacje: Porównuje elementy następnie zwraca wartośc
 autor: Tomasz Stępień
 ************************************** 
*/
function compare( a:Cinema, b:Cinema ){
    if ( a.emptySpaces < b.emptySpaces ){
      return -1;
    }
    if ( a.emptySpaces > b.emptySpaces ){
      return 1;
    }
    return 0;
}
/*
 **************************************
 nazwa funkcji: sortArray
 argumenty: tablica z obiektami Cinema
 typ zwracany: Cinema array
 informacje: brak
 autor: Tomasz Stępień
 ************************************** 
*/

function sortArray(table:Cinema[]){
    const table2 = table;
    return table2.sort( compare );
}

console.log("Po sortowaniu");
var table2 = sortArray(table);
for(var i:number=0;i<10;i++){
    console.log(table2[i].emptySpaces);
}
