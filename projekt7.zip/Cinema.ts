class Cinema{
    nameOfRoom: String;
    emptySpaces: number;
    hour: number;
    nameOfMovie: String;

    constructor(nameOfRoom:String,emptySpaces:number,hour:number,nameOfMovie:String){
        this.nameOfMovie = nameOfMovie;
        this.emptySpaces = emptySpaces;
        this.hour = hour;
        this.nameOfRoom = nameOfRoom;
    }
    /*
    **************************************
    nazwa funkcji: checkIfEnoughSpace
    argumenty: amount, hour, nameOfRoom
    typ zwracany: boolean
    informacje: sprawdza czy sa miejsca w danej sali o danej godzine
    autor: Tomasz Stępień
    ************************************** 
    */
    checkIfEnoughSpace(amount:number, hour:number, nameOfRoom:String){
        
        if(amount<=this.emptySpaces && hour==this.hour && nameOfRoom == this.nameOfRoom){
            return true;
        }else{
            return false;
        }
    }


}