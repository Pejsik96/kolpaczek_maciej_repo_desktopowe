"use strict";
const calc = (a, b) => (console.log(a + b), console.log(a - b), console.log(a * b), console.log(a / b));
function bezwzgledna(a) {
    if (a < 0) {
        a = a * (-1);
    }
    console.log(a);
}
function tab() {
    const numery = [2, 4, 7, 11, 14, 19, 21, 100];
    const parzyste = numery.filter(numery => numery % 2 == 0);
    const nieparzyste = numery.filter(numery => numery % 2 != 0);
    console.log(parzyste + "\n");
    console.log("" + nieparzyste);
}
const osoby = ["Marcin", "Jan", "Beta", "Tadeusz", "Teresa"];
function imiona(osoby) {
    console.log(osoby[Math.floor(Math.random() * osoby.length)]);
}
function losowanie(amount) {
    if (amount == null) {
        amount = 100;
    }
    const tab = [];
    for (let i = 0; i < amount; i++) {
        tab.push(Math.ceil(Math.random() * 100));
    }
    console.log(tab);
    return tab;
}
function podzielne(tab) {
    const nTab = [];
    for (let j = 0; j < tab.length; j++) {
        if (tab[j] % 5 == 0) {
            nTab.push(tab[j]);
        }
    }
    console.log(nTab);
    return nTab;
}
function obliczenia(tab1, tab2) {
    tab1.sort();
    const procent = tab2.length / tab1.length * 100;
    console.log("Otrzymałem tablice z " + tab1.length + " gdzie najmniejsza liczba to " + tab1[0] + " a  największa to " + tab1[tab1.length - 1]);
    console.log("W tym liczby podzielne przez 5: " + tab2 + " czyli " + procent + "% wszystkich liczb");
}
function wyswietl() {
    const tablica = losowanie(10);
    obliczenia(tablica, podzielne(tablica));
}
