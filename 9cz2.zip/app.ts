enum oceny{
    Niedostateczny,
    Dopuszczajacy,
    Dostateczny,
    Dobry,
    BardzoDobry,
    Celujacy
}
let przedmioty=["matematyka","polski","angielski","niemiecki","chemia","biologia","geografia","wos","historia","programowanie"];
let liczbaOcen=parseInt(prompt("Podaj liczbe ocen"));
while(liczbaOcen<1){
    liczbaOcen=parseInt(prompt("Nieprawidlowa ilosc. Podaj liczbe ocen"));
}
for(let i=0; i<liczbaOcen; i++){
    console.log(Math.floor(Math.random() * 6)+1);
}
type ocenyT=[string, number, number, string];
//let temp: ocenyT[]=[['Niedostateczny',1,1,'matematyka']];
for(let i=0; i<4; i++){
    let temp: ocenyT[oceny[i]]
}