var oceny;
(function (oceny) {
    oceny[oceny["ndst"] = 1] = "ndst";
    oceny[oceny["dop"] = 2] = "dop";
    oceny[oceny["dost"] = 3] = "dost";
    oceny[oceny["db"] = 4] = "db";
    oceny[oceny["bdb"] = 5] = "bdb";
    oceny[oceny["cel"] = 6] = "cel";
})(oceny || (oceny = {}));
var przedmioty = ["matematyka", "polski", "angielski", "niemiecki", "chemia", "biologia", "geografia", "wos", "historia", "programowanie"];
var liczbaOcen = parseInt(prompt("Podaj liczbe ocen"));
while (liczbaOcen < 1) {
    liczbaOcen = parseInt(prompt("Nieprawidlowa ilosc. Podaj liczbe ocen"));
}
for (var i = 0; i < liczbaOcen; i++) {
    console.log(Math.floor(Math.random() * 6) + 1);
}
var temp = [['Niedostateczny', 1, 1, 'matematyka']];
console.log(temp[0]);
